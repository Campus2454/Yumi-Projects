import { FC } from 'react';
import { Overlay } from '../utils/styles';
type Props = {
    children: React.ReactNode
}
export const Spinner: FC<Props> = ({ children }) => <Overlay>{children}</Overlay>;