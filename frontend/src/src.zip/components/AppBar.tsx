import { AppBarStyle } from "../utils/styles"
import axios from "axios";
import { User, AuthStatus } from "../utils/types";
import { useContext, useEffect, useState } from "react";
import { getAvatarURL } from "../utils/getURL";
import { GuildContext } from "../utils/contexts/GuildContext";
import { useFetchUser } from "../utils/hooks/useFetchUser";

export const AppBar = () => {
    const { guild } = useContext(GuildContext);
    const { user, error, loading } = useFetchUser();
    const [profile, setProfile] = useState<User>();

    // console.log(guild);
    
    useEffect(() => {
        
    });
    
    if (profile) {
        return (
        <AppBarStyle>
            <p>{profile.global_name}</p>
            {profile.avatar && <img src={getAvatarURL(profile)} alt={profile.username} height={45} width={45} style={{ borderRadius: '50%' }} />}
            {!profile.avatar && <img src='https://cdn.discordapp.com/embed/avatars/0.png' alt={profile.username} height={45} width={45} style={{ borderRadius: '50%' }} />}
        </AppBarStyle>
        )
    }

    return (
        <AppBarStyle>
            {/* <p></p>
            {profile.avatar && <img src={getAvatarURL(profile)} alt={profile.username} height={45} width={45} style={{ borderRadius: '50%' }} />}
            {!profile.avatar && <img src='https://cdn.discordapp.com/embed/avatars/0.png' alt={profile.username} height={45} width={45} style={{ borderRadius: '50%' }} />} */}
        </AppBarStyle>
        );
}