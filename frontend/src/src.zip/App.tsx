import React, { useEffect, useState } from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import { LoginPage } from './pages/LoginPage';
import { MenuPage } from './pages/MenuPage';
import { CategoryPage } from './pages/CategoryPage';
import { GuildPrefixPage } from './pages/GuildPrefixPage';
import { WelcomeMessagePage } from './pages/WelcomeMessagePage';
import { GuildContext } from './utils/contexts/GuildContext';
import { AppBar } from './components/AppBar';
import { useFetchUser } from './utils/hooks/useFetchUser';
import { Spinner } from './components/Spinner';
import { Loading, LoadingEnd } from './pages/LoadingPage';
import axios from 'axios';
import { HomePage } from './pages/HomePage';
import { wait } from '@testing-library/user-event/dist/utils';
import { PartialGuild } from './utils/types';

function App() {
  const [guild, setGuild] = useState<PartialGuild>();
  // const { user, error, loading } = useFetchUser();

  // console.log('Checking server status...');
  // axios.get('https://camming.xyz/api/auth/status')
  //     .then(response => console.log(response.data))
  //     .catch(error => console.error('Error:', error));

  const updateGuild = (guild: PartialGuild) => setGuild(guild);

  // console.log('--------');
  // console.log(user);
  // console.log(error);

  // if (loading) return <Spinner children={<Loading />} />;

  // return <LoginPage />;


  
  useEffect(() => {
    const hideLoading = () => {
      // setTimeout(() => {
        if (document.readyState === 'complete') {
          console.log('Loading: ' + document.readyState);
          const preLoaderBar = document.getElementById('PreLoaderBar');
          if (preLoaderBar) {
            preLoaderBar.style.display = 'none';
          }
        } else {
          console.log('Loading: ' + document.readyState);
          const preLoaderBar = document.getElementById('PreLoaderBar');
          if (preLoaderBar) {
            preLoaderBar.style.display = 'block';
          }
        }
      // }, 2000);
    };

    hideLoading();

    window.addEventListener('load', hideLoading);

    return () => {
      window.removeEventListener('load', hideLoading);
    };
  }, []);
  
  return (
    <GuildContext.Provider value={{ guild, updateGuild, }}>
      {/* <Routes>
        <Route path='*' element={<LoadingEnd />} />
      </Routes> */}
      {/* {user && !error ? (
        <> */}
        <Routes>
          <Route path='*' element={<div className="preLoaderBar backdrop-blur" id="PreLoaderBar"><div className="progress"><div className="indeterminate"></div></div></div>} />
          {/* <Route path='*' element={<AppBar />} /> */}
        </Routes>
        <Routes>
          <Route path='/' element={<LoginPage />} />
          <Route path='/homepagetest' element={<HomePage />} />
          {/* <Route path='/login' element={<Navigate to="/api/auth/login" />} /> */}
          <Route path='/dashboard' element={<MenuPage />} />
          <Route path='/dashboard/:guildId/' element={<CategoryPage />} />
          <Route path='/dashboard/:guildId/prefix' element={<GuildPrefixPage />} />
          <Route path='/dashboard/:guildId/welcome' element={<WelcomeMessagePage />} />
        {/* </Routes>
        </>
      ) : (
        <Routes> */}
          {/* <Route path='/' element={<LoginPage />} /> */}
          {/* <Route path='/login' element={<LoginPage />} /> */}
          {/* <Route path='/guilds' element={<Navigate to="/login" />} />
          <Route path='/dashboard/*' element={<Navigate to="/login" />} /> */}
          <Route path='*' element={<html lang="en"><head><title>Camming - Not Found</title></head><div>Not Found</div></html>} />
        </Routes>
      {/* )} */}
    </GuildContext.Provider>
  );
}

export default App;
