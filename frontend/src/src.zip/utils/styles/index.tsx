import styled, { css } from "styled-components";

export const GuildMenuItemStyle = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 20px;
  background-color: #252525;
  border-radius: 5px;
  border: 1px solid #ffffff14;
  margin: 8px 0;
  transition: 0.2s;

  & > img {
  border-radius: 50%;
  transition: 0.2s;
  }

  & > div {
    border-radius: 50%;
    transition: 0.2s;
    }
  
  &:hover {
    background-color: #333333;
    border-color: #fff;
    cursor: pointer;
    & > img {
    border-radius: 10%;
    }
    & > div {
    border-radius: 10%;
    }
  }
`;

export const GuildMenuItemStyleLoading = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 20px;
  background-color: #252525;
  border-radius: 5px;
  border: 1px solid #ffffff14;
  margin: 8px 0;
`;

export const Container = styled.div`
  width: 60%;
  margin: 0 auto;
`;

export const AppBarStyle = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 35px;
  box-sizing: border-box;
  border-bottom: 1px solid #8f8f8f;
`;

export const Title = styled.p`
  font-size: 22px;
`;

export const InputField = styled.input`
  padding: 5px 16px;
  box-sizing: border-box;
  font-size: 20px;
  color: #fff;
  font-family: "Kanit", sans-serif;
  background-color: #353535;
  border-radius: 5px;
  border: 5px solid #303030;
  transition: 0.2s;
  outline: 1px solid #ffffff00;
  width: 100%;
  &:focus {
    outline: 1px solid #ffffff99;
  }
`;

export const Select = styled.select`
  padding: 5px 16px;
  box-sizing: border-box;
  font-size: 20px;
  color: #fff;
  font-family: "Kanit", sans-serif;
  background-color: #353535;
  border-radius: 5px;
  border: 5px solid #303030;
  transition: 0.2s;
  outline: 1px solid #ffffff00;
  width: 100%;
  cursor: pointer;
  &:focus {
    outline: 1px solid #ffffff99;
  }
`;

export const TextArea = styled.textarea`
  padding: 14px 16px;
  box-sizing: border-box;
  font-size: 16px;
  color: #fff;
  font-family: "Kanit", sans-serif;
  background-color: #353535;
  border-radius: 5px;
  border: 1px solid #3f3f3f;
  outline: none;
  width: 100%;
  height: 120px;
  resize: none;
  :focus {
    outline: 1px solid #ffffff5a;
  }
`;

type ButtonProps = {
  variant: 'primary' | 'secondary';
};

export const Button = styled.button<ButtonProps>`
  padding: 10px 24px;
  border-radius: 5px;
  outline: none;
  border: none;
  font-family: "Kanit", sans-serif;
  font-size: 16px;
  color: #fff;
  cursor: pointer;
  margin-left: 10px;
  margin-right: 10px;
  transition: 0.2s;
  ${({ variant }) =>
    variant === 'primary' &&
    css`
      background-color: #4289ff;

      &:hover {
        background-color: #1c71ff;
      }
    `}
  ${({ variant }) =>
    variant === 'secondary' &&
    css`
      background-color: #3d3d3d;

      &:hover {
        background-color: #282828;
      }
    `}
`;

export const Login = styled.div`
  background-color: rgb(89, 115, 212);
  border-radius: 10px;
  box-shadow: 5px 5px 8px 0px #00000080;
  cursor: pointer;
  transition: 0.2s;

  & > div{
    display: flex;
    align-items: center;
    justify-content: center;
    & > span{
      position: absolute;
      background-color: rgb(70, 0, 0);
      border: 1px solid rgb(61, 0, 0);
      border-radius: 5px;
      padding: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      z-index: 10;
      opacity: 0;
      transform: translateY(-20px);
      transition: 0.2s;
    }
  }

  &:hover {
    background-color: rgb(70, 102, 221);
    
    & > div{
      display: flex;
      align-items: center;
      justify-content: center;
      & > span{
        position: absolute;
        background-color: rgb(70, 0, 0);
        border: 1px solid rgb(61, 0, 0);
        border-radius: 5px;
        padding: 10px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        z-index: 10;
        opacity: 1;
        transform: translateY(0);
      }
    }
  }
`;

export const Login2 = styled.div`
  background-color: rgb(65, 65, 65);
  border-radius: 10px;
  box-shadow: 5px 5px 8px 0px #00000080;
  transition: 0.2s;

  &:hover {
  background-color: rgb(51, 51, 51);
  }
`;

// export const PopupLoginClose = styled.span`
//   display: none;
//   position: absolute;
//   background-color: white;
//   border: 1px solid #ccc;
//   padding: 10px;
//   box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//   z-index: 1000;
// `;

export const Overlay = styled.div`
  height: 100%;
  width: 100%;
  background-color: rgb(59, 59, 59);
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;

export const SlideOut = styled.div`
  background-color: rgb(59, 59, 59);
  animation: slideOut 1s forwards;

  @keyframes slideOut {
    0% { transform: translateY(0); }
    100% { transform: translateY(-100%); }
  }
`;

export const FadeAway = styled.div`
  animation: fadeAway 0.4s forwards;

  @keyframes fadeAway {
    0% { opacity: 1; }
    100% { opacity: 0; }
  }
`;

export const NotFoundImg = styled.div`
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  height: 40%;
  animation: NotFoundImg 4s;

  @keyframes NotFoundImg {
    0% { opacity: 0; top: -50%; }
    50% { opacity: 0; top: -50%; }
    65% { opacity: 0.5; top: 5%; }
    100% { opacity: 1; top: 0%; }
  }
`;

export const NotFoundText = styled.div`
  animation: NotFoundText 5s forwards;

  @keyframes NotFoundText {
    0% { opacity: 0; }
    100% { opacity: 1; }
  }
`;

export const ShowPopupLoadingErrorBox = styled.div`
  display: flex;
  justify-content: center;
  position: fixed;
  bottom: 5%;
  width: 100%;
  animation: PopupBottom 1s forwards cubic-bezier(0, 0, 0, 1);
`;

export const ShowPopupLoadingError = styled.p`
  text-align: center;
  width: 70%;
  background: rgb(74, 74, 74);
  padding: 10px;
  border: 1px solid rgb(31, 31, 31);
  border-radius: 5px;
`;

export const TopBarShortCutLink = styled.a<{ isActive: boolean }>`
  display: flex;
  align-items: center;
  text-decoration: none;
  cursor: pointer;
  color: ${props => props.isActive ? 'rgb(225, 100, 100)' : '#fff'};
  transition: 0.2s;

  @keyframes Zoom-in-out {
    0% { transform: scale(1); }
    50% { transform: scale(1.3); }
    100% { transform: scale(1); }
  }

  & > svg{
    transform: scale(1);
    transition: 0.5s;
  }

  &:hover {
    color: rgb(225, 100, 100);
    & > svg{
      color: #ffa1a1;
      transform: scale(1.2);
    }
  }
`;

export const ItemBarInfoHomePage = styled.button<{ isSelect: boolean }>`
  display: flex;
  align-items: center;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(226, 101, 101, 0);
  padding: 10px;
  cursor: pointer;
  color: ${props => props.isSelect ? 'rgb(225, 100, 100)' : '#fff'};
  transition: 0.2s;

  @keyframes Zoom-in-out {
    0% { transform: scale(1); }
    50% { transform: scale(1.3); }
    100% { transform: scale(1); }
  }

  & > svg{
    transform: scale(1);
    margin-right: 5px;
    transition: 0.5s;
  }

  &:hover {
    color: rgb(225, 100, 100);
    border-bottom: 1px solid rgb(225, 100, 100);
    & > svg{
      color: #ffa1a1;
      transform: scale(1.3);
    }
  }
`;

export const BarInfoHomePage = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 500px;
  border-bottom: 2px solid rgba(255, 255, 255, 0.4);

  @media (max-width: 500px) {
    width: 100%;
    flex-direction: column;
  }
`