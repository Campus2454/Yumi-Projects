import axios, { AxiosRequestConfig } from 'axios';
import { PartialGuild, AuthStatus } from './types';

const CONFIG: AxiosRequestConfig = {
  withCredentials: true,
};

export const getAuthStatus = () => axios.get<AuthStatus>('https://camming.xyz/api/auth/status', CONFIG);
export const getAuthStatusLocalhost = () => axios.get<AuthStatus>('http://210.246.215.139:3001/auth/status', CONFIG);

export const getMutualGuilds = () => axios.get<PartialGuild[]>('https://camming.xyz/api/discord/guilds', CONFIG);
export const getMutualGuildsLocalhost = () => axios.get<PartialGuild[]>('http://210.246.215.139:3001/discord/guilds', CONFIG);