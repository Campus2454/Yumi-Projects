import { useEffect, useState } from "react";
import { getMutualGuilds } from "../api";
import { PartialGuild } from "../types";

export function useFetchGuilds() {
    const [guilds, setGuilds] = useState<PartialGuild[]>();
    const [error, setError] = useState();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        getMutualGuilds()
        .then(({ data }) => {
            console.log(data);
            setGuilds(data);
            setLoading(false);
        })
        .catch((err) => {
            console.error(err);
            setError(err);
        })
        .finally(() => setTimeout(() => setLoading(false), 2000));
    }, []);

    return { guilds, error, loading };
}