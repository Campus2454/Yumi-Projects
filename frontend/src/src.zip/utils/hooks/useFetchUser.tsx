import { useEffect, useState } from "react";
import { getAuthStatus, getAuthStatusLocalhost } from "../api";
import { AuthStatus } from "../types";

export function useFetchUser() {
    const [user, setUser] = useState<AuthStatus>();
    const [error, setError] = useState();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // setLoading(true);
        // getAuthStatus()
        // .then(({ data }) => {
        //     console.log(data);
        //     setUser(data);
        //     setLoading(false);
        // })
        // .catch((err) => {
        //     console.log(err);
        //     setError(err);
        // })
        // .finally(() => setTimeout(() => setLoading(false), 600));

        
        setLoading(true);
        getAuthStatus()
        .then(({ data }) => {
            console.info('User:', data);
            setUser(data);
            setLoading(false);
        })
        .catch(error => {
            if (window.location.hostname != 'camming.xyz')  {
                getAuthStatusLocalhost()
                .then(({ data }) => {
                    console.info('User:', data);
                    setUser(data);
                    setLoading(false);
                })
                .catch(error => {
                    if (error.response) {
                        if (error.response.status == '403') {
                            window.location.href = 'https://discord.com/oauth2/authorize?client_id=1210178730836893719&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A3001%2Fauth%2Fredirect&scope=identify+email+guilds';
                        } else { setError(error.response.status); }
                    } else { setError(error); }
                })
            }else if (error.response) {
                if (error.response.status == '403') {
                    window.location.href = '/login';
                } else { setError(error.response.status); }
            } else { setError(error); }
        })
        .finally(() => setTimeout(() => setLoading(false), 5_000));
    }, []);
    
    return { user, error, loading };
}