export type User = {
    id: string;
    username: string;
    global_name: string;
    avatar: string;
    banner?: string;
    locale?: string;
}

export type PartialGuild = {
    id: string;
    name: string;
    icon: string;
    owner: boolean;
    permissions: string;
    features: string[];
};

export type AuthStatus = {
    id: string;
    discordId: string;
    accessToken: string;
    refreshToken: string;
}