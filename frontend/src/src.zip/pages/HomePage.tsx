import React, { useEffect, useState } from 'react';
import 'aos/dist/aos.css';
import AOS from 'aos';
import { HiPencilAlt } from "react-icons/hi";
import { FaCode, FaHome, FaChartLine } from "react-icons/fa";
import { PiLineVerticalBold } from "react-icons/pi";
import { BsLightningChargeFill } from "react-icons/bs";
import { TopBarShortCutLink, BarInfoHomePage, ItemBarInfoHomePage } from '../utils/styles';
import { useNavigate } from 'react-router-dom';
import { FaBars } from 'react-icons/fa';

export const HomePage = () => {
  const navigate = useNavigate();
  const [menuActive, setMenuActive] = useState(false);
  const [windowWidthLimit, setWindowWidthLimit] = useState(window.innerWidth <= 1000);

  useEffect(() => {
    AOS.init();

    const handleResize = () => {
        setWindowWidthLimit(window.screen.width <= 1000);
        console.log('windowWidthLimit: '+windowWidthLimit);
    };
  }, []);

  const toggleMenu = () => {
    setMenuActive(!menuActive);
  };

//   window.onresize = handleResize();

  return (
    <html>
    <head>
    </head>
    <body>

        {/* Background Fixed*/}
        <div style={{ position: "fixed", zIndex: -50, height: "100%", width: "100%", background: "linear-gradient(160deg, rgb(197 0 0) 0%, rgb(61 0 0) 40%, rgb(0 0 0) 100%)", }}/>

        {/* Top */}
        <div style={{ position: "fixed", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#171717e0", boxShadow: "0 2px 10px 0 rgba(23, 23, 23, 0.88)", top: 0, zIndex: 100, width: "100%", height: 60, maxHeight: "40%", }} >
            <div style={{ display: "flex", justifyContent: "space-between", marginLeft: 20, marginRight: 20, width: "100%", }} >
                <a href="/" style={{ color: "white", textDecoration: "none", width: 150, fontSize: 20, display: "flex", alignItems: "center", }}>
                    <img src="/assets/images/logo2.png" alt="logo" width={40} style={{ borderRadius: 5, marginRight: 15, }} />
                    <span>Camming</span>
                </a>
                <div className={`topBarShortCutLink ${menuActive ? 'mobile-active' : ''}`} style={{ width: "40%", justifyContent: "space-between", alignItems: "center", animation: menuActive ? 'mobile-active-show 0.5s ease-out;' : 'mobile-active-hide 0.5s ease-out;', }}>
                    <TopBarShortCutLink href='/homepagetest' isActive={window.location.pathname == '/homepagetest'}>
                        <FaHome style={{ marginRight: 10, }} />
                        <span>Home</span>
                    </TopBarShortCutLink>
                    <TopBarShortCutLink isActive={window.location.pathname == '/null'}>
                        <span>item2</span>
                    </TopBarShortCutLink>
                    <TopBarShortCutLink isActive={window.location.pathname == '/null'}>
                        <span>item3</span>
                    </TopBarShortCutLink>
                    <TopBarShortCutLink isActive={window.location.pathname == '/null'}>
                        <span>item4</span>
                    </TopBarShortCutLink>
                    <TopBarShortCutLink isActive={window.location.pathname == '/null'}>
                        <span>item5</span>
                    </TopBarShortCutLink>
                </div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", width: 150, }}>
                    <a style={{ display: "flex", alignItems: "center",  cursor: "pointer", opacity: 0.5, }}>
                        <img src="/assets/images/person-circle.png" alt="logo" width={40} />
                    </a>
                    <div className="profile" style={{ marginRight: 20, }}/>
                    <div className="hamburger profile" onClick={toggleMenu} style={{ alignItems: "center", }}>
                        <FaBars color="white" size={20} />
                    </div>
                </div>
            </div>
        </div>

        {/* Part1 */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", height: "100vh", backgroundColor: "rgb(46, 46, 46)", }}>
            <div>
                <h1 style={{ color: "rgb(181, 181, 181)", }}>Waiting for this part from 'kxnomtom'</h1>
                {/* <div>
                    <h1>บอทสารพัดประโยชน์ <span>Camming</span></h1>
                    <p>Make your server perfect and secure by inviting this bot
                    </p>
                    <div>
                        <a href="https://camming.xyz/invite" target="_blank">
                        <button>Invite</button></a>
                        <a href="https://camming.xyz/discord" target="_blank">
                        <button>Join Server</button></a>
                    </div>
                </div>
                <figure>
                    <img src="https://camming.xyz/assets/images/logo.png" alt="nft art" />
                </figure> */}
            </div>
        </div>

        {/* Part2 */}
        <div style={{ minHeight: "70vh", }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", paddingTop: 100, paddingBottom: 100, flexDirection: "column", }}>
                <BarInfoHomePage>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexWrap: "wrap", minWidth: "80%", }}>
                        <ItemBarInfoHomePage isSelect={false}>
                            <FaChartLine />
                            <span style={{ background: "none", border: "none", font: "14px Kanit", }}>Statistics</span>
                        </ItemBarInfoHomePage>
                        <PiLineVerticalBold />
                        <ItemBarInfoHomePage isSelect={false}>
                        <FaCode style={{ width: 15, height: 15, }} />
                            <span style={{ background: "none", border: "none", font: "14px Kanit", }}>Developers</span>
                        </ItemBarInfoHomePage>
                        <PiLineVerticalBold />
                        <ItemBarInfoHomePage isSelect={false}>
                            <BsLightningChargeFill />
                            <span style={{ background: "none", border: "none", font: "14px Kanit", }}>Status</span>
                        </ItemBarInfoHomePage>
                        <PiLineVerticalBold />
                        <ItemBarInfoHomePage isSelect={false}>
                            <HiPencilAlt style={{ width: 15, height: 15, }} />
                            <span style={{ background: "none", border: "none", font: "14px Kanit", }}>Change Log</span>
                        </ItemBarInfoHomePage>
                    </div>
                </BarInfoHomePage>
                <div style={{ height: "50px", }}/>
                <div id="Statistics" data-aos="fade-up" data-aos-duration="500" style={{ display: "flex", flexDirection: "row", flexWrap: "wrap", justifyContent: "center", textAlign: "center", width: 700, }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", backgroundColor: "#d23030", width: 220, height: 220, borderRadius: 10, margin: "0px 10px", }}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 0 512 512"><path fill="#ffffff" d="M64 32C28.7 32 0 60.7 0 96l0 64c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-64c0-35.3-28.7-64-64-64L64 32zm280 72a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm48 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zM64 288c-35.3 0-64 28.7-64 64l0 64c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-64c0-35.3-28.7-64-64-64L64 288zm280 72a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm56 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0z"/></svg>
                        <h1 style={{ margin: 0, }}>number</h1>
                        <span style={{ fontSize: 15, margin: 0, }}>Servers</span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", backgroundColor: "#d23030", width: 220, height: 220, borderRadius: 10, margin: "0px 10px", }}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 0 640 512"><path fill="#ffffff" d="M144 0a80 80 0 1 1 0 160A80 80 0 1 1 144 0zM512 0a80 80 0 1 1 0 160A80 80 0 1 1 512 0zM0 298.7C0 239.8 47.8 192 106.7 192l42.7 0c15.9 0 31 3.5 44.6 9.7c-1.3 7.2-1.9 14.7-1.9 22.3c0 38.2 16.8 72.5 43.3 96c-.2 0-.4 0-.7 0L21.3 320C9.6 320 0 310.4 0 298.7zM405.3 320c-.2 0-.4 0-.7 0c26.6-23.5 43.3-57.8 43.3-96c0-7.6-.7-15-1.9-22.3c13.6-6.3 28.7-9.7 44.6-9.7l42.7 0C592.2 192 640 239.8 640 298.7c0 11.8-9.6 21.3-21.3 21.3l-213.3 0zM224 224a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zM128 485.3C128 411.7 187.7 352 261.3 352l117.3 0C452.3 352 512 411.7 512 485.3c0 14.7-11.9 26.7-26.7 26.7l-330.7 0c-14.7 0-26.7-11.9-26.7-26.7z"/></svg>
                        <h1 style={{ margin: 0, }}>number</h1>
                        <span style={{ fontSize: 15, margin: 0, }}>Members</span>
                    </div>
                    {/* <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", backgroundColor: "#d23030", width: 220, height: 220, borderRadius: 10, padding: "0px 10px", }}>
                        <h1 style={{ margin: 0, }}>null</h1>
                        <span style={{ fontSize: 15, margin: 0, }}>Premium bots</span>
                    </div> */}
                </div>
            </div>
        </div>
        
        {/* Part3 */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "70px", width: "100%", background: "rgb(46, 46, 46)", }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "85%", }}>
                <div style={{ color: "#b5b5b5", }}>
                    © 2024 Camming All Rights Reserved.
                </div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", minWidth: "25%", }}>
                    <a href="" style={{ color: "#b5b5b5", textDecoration: "none", }}>Privacy Policy</a>
                    <a href="" style={{ color: "#b5b5b5", textDecoration: "none", }}>Terms &amp; Conditions</a>
                </div>
            </div>
        </div>
    </body>
    </html>
  );
};
