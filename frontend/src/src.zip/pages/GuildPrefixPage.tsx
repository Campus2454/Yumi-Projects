import { useEffect } from "react";
import { Button, Container, InputField, Title } from "../utils/styles";

export const GuildPrefixPage = () => {
useEffect(() => {
    const inputField = document.getElementById('prefix');
    if (inputField) {
        inputField.addEventListener('input', function() {
            const inputValue = (inputField as HTMLInputElement).value.replace(/\s/g, '');
            const lowercaseValue = inputValue.toLowerCase();
            (inputField as HTMLInputElement).value = lowercaseValue;
        });
    }
}, []);
return <div>
    <Container style={{ width: '800px', }}>
        <Title className='kanit-extrabold'>Update Command Prefix</Title>
        <form>
            <div>
                <label htmlFor="prefix">Current Prefix</label>
            </div>
            <InputField id='prefix' maxLength={1} placeholder='Example: ?' 
                style={{ marginTop: '15px', marginBottom: '15px', }} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', }}>
                <Button variant="secondary" type="button">Reset</Button>
                <Button variant="primary">Save</Button>
            </div>
        </form>
    </Container>
</div>

}