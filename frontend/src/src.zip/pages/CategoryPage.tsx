import { useContext } from "react";
import { GuildContext } from "../utils/contexts/GuildContext";
import { Container, Title } from "../utils/styles";
import { IoSettingsOutline, IoNewspaperOutline } from "react-icons/io5";
import { useNavigate } from "react-router-dom";

export const CategoryPage = () => {
    const { guild } = useContext(GuildContext)
    const navigate = useNavigate();

    return (
        <div style={{ padding: '40px 0'}}>
            <Container>
                <div style={{ background: 'rgb(100 100 100)', padding: '20px', border: '5px solid rgb(116 116 116)', borderRadius: '10px', }}>
                    <div style={{ display: 'flex', alignItems: 'center', height: '40px', }}>
                        <IoSettingsOutline size={30} style={{ paddingRight: '15px', }} />
                        <Title>Basic Configurations</Title>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', fontSize: '20px', }}>
                        <div style={{ padding: '12px', }}>
                            <div className='pointer' onClick={() => navigate(`/dashboard/${guild}/prefix`)} style={{ padding: '10px', background: '#373737', width: '190px', borderRadius: '5px', }}>
                                Command Prefix
                            </div>
                        </div>
                        <div style={{ padding: '12px', }}>
                            <div className='pointer' onClick={() => navigate(`/dashboard/${guild}/welcome`)} style={{ padding: '10px', background: '#373737', width: '210px', borderRadius: '5px', }}>
                                Welcome new member
                            </div>
                        </div>
                    </div>
                </div>
                <div style={{ padding: '10px', }}/><div style={{ border: '1px solid #8b8b8b', }}/><div style={{ padding: '10px', }}/>
                <div style={{ background: 'rgb(100 100 100)', padding: '20px', border: '5px solid rgb(116 116 116)', borderRadius: '10px', }}>
                    <div style={{ display: 'flex', alignItems: 'center', height: '40px', }}>
                        <IoNewspaperOutline size={30} style={{ paddingRight: '15px', }} />
                        <Title>Channel Logs</Title>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', fontSize: '20px', }}>
                        <div style={{ padding: '12px', }}>
                            <div className='pointer' onClick={() => navigate(``)} style={{ padding: '10px', background: '#373737', width: '210px', borderRadius: '5px', }}>
                                Bot Update
                            </div>
                        </div>
                        <div style={{ padding: '12px', }}>
                            <div className='pointer' onClick={() => navigate(``)} style={{ padding: '10px', background: '#373737', width: '200px', borderRadius: '5px', }}>
                                Audit logs
                            </div>
                        </div>
                        <div style={{ padding: '12px', }}>
                            <div className='pointer' onClick={() => navigate(``)} style={{ padding: '10px', background: '#373737', width: '190px', borderRadius: '5px', }}>
                                Moderation Logs
                            </div>
                        </div>
                    </div>
                </div>
            </Container>
        </div>
    );
};