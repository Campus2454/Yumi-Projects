import { redirect, useNavigate } from "react-router-dom";
import { mockGuilds } from "../__mocks__/guilds";
import { useContext, useState, useEffect } from "react";
import { GuildContext } from "../utils/contexts/GuildContext";
import { GuildMenuItem } from "../components/GuildMenuItem";
import { Container, GuildMenuItemStyle, GuildMenuItemStyleLoading, NotFoundImg, NotFoundText, ShowPopupLoadingErrorBox, ShowPopupLoadingError } from "../utils/styles";
import { useFetchUser } from "../utils/hooks/useFetchUser";
import axios from "axios";
import { PartialGuild, AuthStatus } from "../utils/types";
import { getMutualGuilds, getAuthStatus, getAuthStatusLocalhost, getMutualGuildsLocalhost } from "../utils/api";
// import { wait } from "@testing-library/user-event/dist/utils";
import { useFetchGuilds } from "../utils/hooks/useFetchGuilds";

export const MenuPage = () => {
    const [loading, setLoading] = useState(true);
    const [loadingGuilds, setLoadingGuilds] = useState(true);
    const [user, setUser] = useState<AuthStatus>();
    const [guilds, setGuilds] = useState<PartialGuild[]>();
    const [error, setError] = useState('');
    const [showPopupLoadingError, setShowPopupLoadingError] = useState(false);
    const [internetError, setInternetError] = useState(false);

    const navigate = useNavigate();
    const { updateGuild } = useContext(GuildContext);

    const handleClick = (guild: PartialGuild) => {
        console.log(guild);
        updateGuild(guild);
        // navigate(`/dashboard/${guild.id}/main`);
        window.location.href = `/dashboard/${guild.id}/main`;
    };

    if (window.location.href == 'https://camming.xyz/dashboard/'){window.location.href = 'https://camming.xyz/dashboard';};

    // return (
    // <html lang="en">
    //     <head>
    //         <title>Camming - Dashboard</title>
    //     </head>
    //     <div>
    //         <Container><h2>Select a Server</h2></Container>
    //         <Container>
    //             <GuildMenuItemStyle>
    //                 <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
    //                 <p>Loading . .</p>
    //             </GuildMenuItemStyle>
    //             <GuildMenuItemStyle>
    //                 <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
    //                 <p>Loading . .</p>
    //             </GuildMenuItemStyle>
    //             <GuildMenuItemStyle>
    //                 <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
    //                 <p>Loading . .</p>
    //             </GuildMenuItemStyle>
    //         </Container>
    //     {/* <div>
    //         <Container><h2>Select a Server</h2></Container>
    //         {mockGuilds.map((guild) => (
    //             <Container>
    //                 <div onClick={() => handleClick(guild.id)}>
    //                     <GuildMenuItem guild={guild}/>
    //                 </div>
    //             </Container>
    //         ))}
    //     </div> */}
    //     </div>
    // </html>
    // );

    useEffect(() => {
        setLoading(true);
        getAuthStatus()
        .then(({ data }) => {
            console.info('User:', data);
            setUser(data);
            setLoading(false);
            setLoadingGuilds(true);
            getMutualGuilds()
            .then(({ data }) => {
                console.info('Guilds:', data);
                setGuilds(data);
                setLoadingGuilds(false);
            })
            .catch((err) => {
                // wait(2_000);
                getMutualGuilds()
                .then(({ data }) => {
                    console.info('Guilds:', data);
                    setGuilds(data);
                    setLoadingGuilds(false);
                })
                .catch((err) => {
                    console.error(err);
                    setError(err);
                })
                .finally(() => setTimeout(() => setLoadingGuilds(false), 2_000));
            })
            .finally(() => setTimeout(() => setLoadingGuilds(false), 2_000));
        })
        .catch(error => {
            if (window.location.href != 'https://camming.xyz/dashboard')  {
                getAuthStatusLocalhost()
                .then(({ data }) => {
                    console.info('User:', data);
                    setUser(data);
                    setLoading(false);
                    setLoadingGuilds(true);
                    getMutualGuildsLocalhost()
                    .then(({ data }) => {
                        console.info('Guilds:', data);
                        setGuilds(data);
                        setLoadingGuilds(false);
                    })
                    .catch((err) => {
                        // wait(2_000);
                        getMutualGuildsLocalhost()
                        .then(({ data }) => {
                            console.info('Guilds:', data);
                            setGuilds(data);
                            setLoadingGuilds(false);
                        })
                        .catch((err) => {
                            console.error(err);
                            setError(err);
                        })
                        .finally(() => setTimeout(() => setLoadingGuilds(false), 2_000));
                    })
                    .finally(() => setTimeout(() => setLoadingGuilds(false), 2_000));
                })
                .catch(error => {
                    if (error.response) {
                        if (error.response.status == '403') {
                            window.location.href = 'https://discord.com/oauth2/authorize?client_id=1210178730836893719&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A3001%2Fauth%2Fredirect&scope=identify+email+guilds';
                        } else { setError(error.response.status); }
                    } else { setError(`${error}`); }
                })
            }else if (error.response) {
                if (error.response.status == '403') {
                    window.location.href = '/login';
                } else { setError(error.response.status); }
            } else { setError(`${error}`); }
        })
        .finally(() => setTimeout(() => setLoading(false), 5_000));

        if (loading) {
            const timeShowPopupLoadingError = setTimeout(() => {
                setShowPopupLoadingError(true);
            }, 3000);
            return () => clearTimeout(timeShowPopupLoadingError);
        }
    }, []);
    
    //   const handleClick = (guild: PartialGuild) => {
    //     history.push(`/guilds/${guildId}`);
    //   };


      if (loading) {
        return (
            <html>
            <head>
                <title>Loading</title>
            </head>
            <div>
                <Container><h2>Loading User<span className='loadingDot'></span></h2></Container>
                <Container>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                </Container>
                {showPopupLoadingError && (
                    <ShowPopupLoadingErrorBox>
                        <ShowPopupLoadingError>
                        If there is a problem obtaining user information, please contact the system administrator: <a href="https://discord.gg/brxPZB3Jzy" style={{ color: '#ff8f8f', textDecorationColor: '#ffbdbd' }} >Discord</a>
                        </ShowPopupLoadingError>
                    </ShowPopupLoadingErrorBox>
                )}
            </div>
            </html>
        );
      }

      if (user && loadingGuilds && !error) {
        return (
            <html>
            <head>
                <title>Loading</title>
            </head>
            <div>
                <Container><h2>Loading Guilds<span className='loadingDot'></span></h2></Container>
                <Container>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                <GuildMenuItemStyleLoading>
                    <div style={{ background: '#707070', borderRadius: '50%', width: '40px', height: '40px', }}></div>
                    <p style={{ background: '#707070', borderRadius: '5px', height: '25px', width: '30%', marginTop: '16px', marginBottom: '16px', }}></p>
                </GuildMenuItemStyleLoading>
                </Container>
                {showPopupLoadingError && (
                    <ShowPopupLoadingErrorBox>
                        <ShowPopupLoadingError>
                        If there is a problem obtaining user information, please contact the system administrator: <a href="https://discord.gg/brxPZB3Jzy" style={{ color: '#ff8f8f', textDecorationColor: '#ffbdbd' }} >Discord</a>
                        </ShowPopupLoadingError>
                    </ShowPopupLoadingErrorBox>
                )}
            </div>
            </html>
        );
      }

      if (guilds && !error) {
        return (
            <html>
            <head>
                <title>Guilds - Camming</title>
            </head>
            <div>
                <Container><h2>Select a Server</h2></Container>
                {guilds.map((guild) => (
                <Container>
                    <div onClick={() => handleClick(guild)}>
                    <GuildMenuItem guild={guild} />
                    </div>
                </Container>
                ))}
            </div>
            </html>
        )
      }
    
      if (error) {
        return (
            <html>
            <head>
                <title>Not Found - {error}</title>
            </head>
            <NotFoundImg>
                <img src='../assets/not-found/not found1.png' alt='Not Found' width={130} height={130} />
            </NotFoundImg>
            <NotFoundText style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
                <h2>Not Found</h2>
                <p style={{ margin: '0' }}>
                    {error}
                </p>
                <p style={{ margin: '0' }}>
                    <div>Back to <a href='/' style={{ color: '#ff8f8f', textDecorationColor: '#ffbdbd' }}>Home Page</a></div>
                </p>
            </NotFoundText>
            {showPopupLoadingError && (
                <ShowPopupLoadingErrorBox>
                    <ShowPopupLoadingError>
                    If there is a problem obtaining user information, please contact the system administrator: <a href="https://discord.gg/brxPZB3Jzy" style={{ color: '#ff8f8f', textDecorationColor: '#ffbdbd' }} >Discord</a>
                    </ShowPopupLoadingError>
                </ShowPopupLoadingErrorBox>
            )}
            </html>
        );
      };

      return (
          <html>
            <head>
                <title>Not Found - Camming</title>
            </head>
            <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
                <h2>Not Found</h2>
                <p style={{ margin: '0' }}>
                    <div>Back to <a href='/' style={{ color: '#ff8f8f', textDecorationColor: '#ffbdbd' }}>Home Page</a></div>
                </p>
            </div>
          </html>
      );
    };
