import { FadeAway, SlideOut } from "../utils/styles";
import { Spinner } from '../components/Spinner';
import { BarLoader } from "react-spinners";
import { useEffect, useState } from "react";
import styled from "styled-components";

export const LoadingEnd = () => {
    return <SlideOut className="loading-end">
        <FadeAway>
            <Spinner>
                <Loading />
            </Spinner>
        </FadeAway>
    </SlideOut>
}

export const Loading = () => {
    return <html lang="en">
        <head>
            <title>Loading...</title>
        </head><Spinner>
        <h3>Loading...</h3>
        <BarLoader color='#fff' width={150} height={5} />
    </Spinner>
    </html>
}




