import { FaDiscord, FaQuestionCircle } from 'react-icons/fa';
import { Login, Login2 } from "../utils/styles";
import { useRef } from 'react';

export const LoginPage = () => {
    // const popupRef = useRef<HTMLSpanElement>(null);
    // const popupLoginClose = (event: React.MouseEvent) => {
    //     const popup = popupRef.current;
    //     const link = event.target as HTMLAnchorElement;
        
    //     if (!popup) return;
        
    //     // กำหนดตำแหน่งของป๊อปอัพให้ตรงกับตำแหน่งของปุ่ม
    //     popup.style.left = `${link.offsetLeft}px`;
    //     popup.style.top = `${link.offsetTop + link.offsetHeight}px`;
        
    //     // แสดงป๊อปอัพ
    //     popup.style.display = 'block';
        
    //     // ซ่อนป๊อปอัพเมื่อคลิกนอกป๊อปอัพ
    //     document.addEventListener('click', function hidePopup(e) {
    //         if (!popup.contains(e.target as Node) && !link.contains(e.target as Node)) {
    //             popup.style.display = 'none';
    //             document.removeEventListener('click', hidePopup);
    //         }
    //     });
    // };

    const redirect = (event: React.MouseEvent) => {
        window.location.href = 'https://camming.xyz/api/auth/login';
        // popupLoginClose(event);
    };

    return (
    <html lang="en">
        <head>
            <title>Login - Camming</title>
        </head>
        <div style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            height: "100vh",
            width: "100vw",
            padding: "20px 0px",
            boxSizing: "border-box",
        }}>
            <div></div>
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', blockSize: '150px', }}>
                <a onClick={redirect}>
                    <Login>
                    <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column', width: '300px', borderRadius: '10px', }}>
                        <div style={{ display: 'flex', width: '230px', justifyContent: 'flex-start', alignItems: 'center', }}>
                            <FaDiscord size={35} />
                            <p style={{paddingLeft: '30px', fontSize: '20px'}}>Login with Discord</p>
                        </div>
                    </div>
                    {/* <div>
                        <span>Login temporarily disabled</span>
                    </div> */}
                    </Login>
                </a>
                <a href='https://discord.gg/brxPZB3Jzy' target='_blank' style={{ textDecoration: 'none', }}>
                    <Login2>
                    <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column', width: '300px', borderRadius: '10px', color: '#fff', }}>
                        <div style={{ display: 'flex', width: '230px', justifyContent: 'flex-start', alignItems: 'center', }}>
                            <FaQuestionCircle size={35}/>
                            <p style={{paddingLeft: '30px', fontSize: '20px'}}>Support server</p>
                        </div>
                    </div>
                </Login2></a>
            </div>
            <div style={{ display: 'flex', width: '400px', justifyContent: 'space-between' }}>
                <span>Privacy Policy</span>
                <span>Terms of Service</span>
                <span>Contact Us</span>
            </div>
        </div>
    </html>
    )
}