import { Button, Container, Select, TextArea, Title } from "../utils/styles";

export const WelcomeMessagePage = () => <div>
<Container style={{ width: '800px', }}>
    <Title className='kanit-extrabold'>Update Welcome Message</Title>
    <form>
        <section>
            <div>
                <label>Current Channel</label>
            </div>
            <Select style={{ marginTop: '15px', marginBottom: '15px', }}>
                <option disabled>none</option>
                <option>123</option>
                <option>234</option>
                <option>456</option>
                <option>567</option>
                <option>678</option>
                <option>789</option>
            </Select>
        </section>
        <section>
            <div>
                <label>Current Message</label>
            </div>
            <TextArea id="message" maxLength={2000} />
        </section>
        <div style={{ display: 'flex', justifyContent: 'flex-end', }}>
            <Button variant="secondary" type="button">Reset</Button>
            <Button variant="primary">Save</Button>
        </div>
    </form>
</Container>
</div>
