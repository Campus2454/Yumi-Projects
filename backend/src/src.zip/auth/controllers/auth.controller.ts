import { Controller, Get, Post, Res, UseGuards } from '@nestjs/common';
import { ROUTES } from '../../utils/constants';
import { AuthenticatedGuard, DiscordAuthGuard } from '../utils/Guards';
import { Response } from 'express';
import { AuthUser } from 'src/utils/decorators';
import { User } from 'src/utils/typeorm/entities/User';

@Controller(ROUTES.AUTH)
export class AuthController {

    @Get('login')
    @UseGuards(DiscordAuthGuard)
    login() {}

    @Get('redirect')
    @UseGuards(DiscordAuthGuard)
    redirect(@Res() res: Response) {
        res.redirect('https://camming.xyz/dashboard');
    }

    @Get('status')
    @UseGuards(AuthenticatedGuard)
    status(@AuthUser() user: User) {
        return user;
    }

    @Post('logout')
    logout() {}
}
