export interface IDiscordService {
    getBotGuilds();
    getUserGuilds(accessToken: string);
    gerMutualGuilds(accessToken: string);
}