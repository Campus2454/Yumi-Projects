import { Inject, Injectable } from "@nestjs/common";
import { IDiscordService } from "../interfaces/discord";
import { SERVICES } from "src/utils/constants";
import { IDiscordHttpService } from "../interfaces/discord-http";

@Injectable()
export class DiscordService implements IDiscordService {
    constructor(@Inject(SERVICES.DISCORD_HTTP) private readonly discordHttpService: IDiscordHttpService){}
    getBotGuilds(){
        return this.discordHttpService.fetchBotGuilds();
    }
    getUserGuilds(accessToken: string){
        return this.discordHttpService.fetchUserGuilds(accessToken);
    }
    async gerMutualGuilds(accessToken: string){
        const { data: userGuilds } = await this.getUserGuilds(accessToken);
        const { data: botGuilds } = await this.getBotGuilds();
        // userGuilds.forEach((guild) => {
        //     const permissions = parseInt(guild.permissions) & 0x8;
        //     console.log(permissions);
        // })
        const adminUserGuilds = userGuilds.filter(({ permissions }) => (parseInt(permissions) & 0x8) === 8)
        const mutualGuilds = userGuilds.filter((guild) => botGuilds.some((botGuilds) => botGuilds.id === guild.id))
        return mutualGuilds;
    }
}