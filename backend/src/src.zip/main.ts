import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as session from 'express-session';
import * as passport from 'passport';
import { TypeormStore } from 'connect-typeorm';
import { Connection, ConnectionOptions, createConnection, getRepository } from 'typeorm';
import { Session } from './utils/typeorm/entities/Session';
import { entities } from './utils/typeorm';
import * as cors from 'cors';


async function bootstrap() {
  const chalk = require('chalk');
  await createConnection({
    type: 'mysql',
    host: process.env.MYSQL_DB_HOST,
    port: 3306,
    username: process.env.MYSQL_DB_USER,
    password: process.env.MYSQL_DB_PASSWORD,
    database: process.env.MYSQL_DB_DATABASE,
    synchronize: true,
    entities: entities,
  })
  .then(() => {console.log((chalk.green(' - ✔')),'Connected to the database successfully.');})
  .catch((error) => {console.log((chalk.red(' - ✖',error)));});
  const sessionRepository = getRepository(Session);

  const app = await NestFactory.create(AppModule);

  // app.setGlobalPrefix('api');

  app.use(
    session({
      secret: process.env.COOKIE_SECRET,
      resave: false,
      saveUninitialized: false, 
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 30,
      },
      store: new TypeormStore().connect(sessionRepository),
    }),
  );

  const whitelist = ['http://localhost:3000' && 'https://camming.xyz'];

  app.enableCors({
    origin: ['http://localhost:3000'],
    credentials: true,
  });
  app.use(passport.initialize());
  app.use(passport.session());

  try {
    await app.listen(process.env.PORT);
    console.log(`Running on Port: ${process.env.PORT}`)
  } catch (err) {
    console.log(err);
  }
}
bootstrap();
