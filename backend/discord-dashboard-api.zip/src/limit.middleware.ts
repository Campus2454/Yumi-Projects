import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class LimitMiddleware implements NestMiddleware {
  private userRequests = new Map<string, { count: number; lastRequestTime: number }>();
  private readonly limit = 10;  // กำหนด limit ที่อนุญาต
  private readonly windowTime = 1_000;  // เวลาหน่วง

  use(req: Request, res: Response, next: NextFunction) {
    const userId = req.ip; // หรือใช้ข้อมูลอย่างอื่นเพื่อระบุผู้ใช้ เช่น req.user.id ถ้าคุณใช้การยืนยันตัวตน
    const currentTime = Date.now();

    // ตรวจสอบว่าใน - วินาทีที่ผ่านมาเคยมี request จากผู้ใช้หรือไม่
    if (!this.userRequests.has(userId)) {
      this.userRequests.set(userId, { count: 1, lastRequestTime: currentTime });
    } else {
      const userData = this.userRequests.get(userId);
      if (userData) {
        const timeElapsed = currentTime - userData.lastRequestTime;

        // ถ้าเกิน 10 วินาที ให้รีเซ็ตการนับ
        if (timeElapsed > this.windowTime) {
          userData.count = 1;  // รีเซ็ตจำนวน request
          userData.lastRequestTime = currentTime;  // อัพเดตเวลาล่าสุด
        } else {
          userData.count += 1;  // เพิ่มจำนวน request
        }

        // ตรวจสอบจำนวน request ว่าถึง limit หรือไม่
        if (userData.count > this.limit) {
          return res.status(429).send('Limit reached, try again later');
        }
      }
    }

    next();
  }
}
