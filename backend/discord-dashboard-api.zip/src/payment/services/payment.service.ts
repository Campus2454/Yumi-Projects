import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Payment } from 'src/utils/typeorm/entities/Payment';
import { User } from 'src/utils/typeorm/entities/user';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class PaymentService {
    @InjectRepository(Payment) private readonly paymentRepo: Repository<Payment>
    @InjectRepository(User) private readonly userRepo: Repository<User>

    async submitPayment(data: { discordId: string, slipUrl: string, membershipType: string, amount: number }) {
        const user = await this.userRepo.findOne({ where: { discordId: data.discordId } });
        if(!user){
            throw new Error('User not found');
        };

        const newPayment = this.paymentRepo.create({
            discordId: data.discordId,
            slipUrl: data.slipUrl,
            membershipType: data.membershipType,
            amount: data.amount,
        });

        return await this.paymentRepo.save(newPayment);
    }

    async verifyPayment(discordId: string) {
        const payment = await this.paymentRepo.findOne({ where: { discordId } });
        if(!payment){
            throw new Error('Payment not found');
        };

        payment.isVerified = true;
        return await this.paymentRepo.save(payment);
    }
}