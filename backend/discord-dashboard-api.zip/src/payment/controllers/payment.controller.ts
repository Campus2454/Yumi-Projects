import { Controller, Post, Put, Body, Param, Res, UseGuards, Headers } from '@nestjs/common';
import { Response } from 'express';
import { PaymentService } from '../services/payment.service';
import { AuthenticatedGuard } from 'src/auth/utils/Guards';

@Controller('payment')
export class PaymentController {
    constructor(private readonly paymentService: PaymentService) {}

    @Post('submit')
    @UseGuards(AuthenticatedGuard)
    async submitPayment(
        @Body() data: { discordId: string; slipUrl: string; membershipType: string; amount: number },
        @Res() res: Response,
        @Headers('x-api-key') apiKey: string
    ) {
        if(apiKey !== process.env.PAYMENT_ADMIN_KEY){
            return res.status(401).json({ success: false, message: 'Unauthorized access' });
        };

        if(!data.discordId || !data.slipUrl || !data.membershipType || !data.amount){
            return res.status(401).json({ success: false, message: 'Missing required fields' });
        };

        if (!data.slipUrl.match(/^https?:\/\/[^\s$.?#].[^\s]*$/)) {
            return res.status(400).json({ success: false, message: 'Invalid slip URL' });
        }
        
        try{
            const result = await this.paymentService.submitPayment(data);
            return res.status(200).json({ success: true, result });
        }catch(error){
            return res.status(500).json({ success: false, message: error.message });
        }
    }

    @Put('verify/:discordId')
    @UseGuards(AuthenticatedGuard)
    async verifyPayment(
        @Param('discordId') discordId: string,
        @Res() res: Response,
        @Headers('x-api-key') apiKey: string
    ) {
        if(apiKey !== process.env.PAYMENT_ADMIN_KEY){
            return res.status(401).json({ success: false, message: 'Unauthorized access' });
        };

        try{
            const result = await this.paymentService.verifyPayment(discordId);
            return res.status(200).json({ success: true, result });
        }catch(error){
            return res.status(500).json({ success: false, message: error.message });
        }
    }
}