import { AxiosResponse } from "axios";
import { Guild } from "discord.js";
import { PartialGuild, UserData } from "src/utils/types";

export interface IDiscordHttpService {
    fetchBotGuilds(): Promise<AxiosResponse<PartialGuild[]>>;
    fetchUserGuilds(accessToken: string): Promise<AxiosResponse<PartialGuild[]>>;
    fetchUserData(accessToken: string): Promise<AxiosResponse<UserData>>;
    fetchGuildData(guildId: string): Promise<AxiosResponse<Guild>>;
}