import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Client, GatewayIntentBits, Locale } from "discord.js";
import { Response } from "express";
import { GuildConfiguration } from "src/utils/typeorm/entities/GuildConfiguration";
import { GuildConfig } from "src/utils/types";
import { Repository } from "typeorm";

@Injectable()
export class GuildConfigService {
    private client: Client;
    constructor(
        @InjectRepository(GuildConfiguration) private readonly guildConfigRepository: Repository<GuildConfiguration>
    ){
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
            ],
        });
        this.client.login(process.env.DISCORD_BOT_TOKEN);
        this.client.once('ready', () => {
            console.log('GuildConfigService: Discord bot is online!');
        });
    }

    async setConfig(config: GuildConfig, res: Response) {
        if(config.guildSettings && config.guildSettings.guildId && config.guildSettings.language && config.guildSettings.prefix){
            try{
                const guildConfig = await this.guildConfigRepository.findOne({ where: { guildId: config.guildSettings.guildId } });
                const newConfig = { ...guildConfig, prefix: config.guildSettings.prefix };
                const saveConfig = await this.guildConfigRepository.save(newConfig);
                let newLocale = null;
                let newGuildConfig = { config: null, statusText: null, error: null };
                const guild = await (await this.client.guilds.fetch()).get(config.guildSettings.guildId).fetch();
                if(guild && Object.values(Locale).includes(config.guildSettings.language as Locale)){
                    const locale = config.guildSettings.language as Locale;
                    try{
                        guild.setPreferredLocale(locale);
                    }catch(error){
                        newGuildConfig.error = 'Bot cannot save locale values to guild.';
                    }finally{
                        const guild = await (await this.client.guilds.fetch()).get(config.guildSettings.guildId).fetch();
                        newLocale = guild.preferredLocale ? guild.preferredLocale : null;
                    }
                };
                newGuildConfig.config = { ...saveConfig, language: newLocale };
                newGuildConfig.statusText = 'Saved Config Successfully';
                return res.status(200).json(newGuildConfig);
            }catch(error){
                if(error.response?.status === 429){
                    return res.status(429).send('Rate limit exceeded. Please try again later.');
                };
                console.error('Error:', error);
                return res.status(500).json({ error: 'An unexpected error occurred.' });
            };
        }else return res.status(404).send('Error: 404 Not Found');
    }

    async getConfig(guildId: string, res: Response) {
        return res.status(404).send('Error: This function is not supported at this time.');
    }

    async delConfig(config: GuildConfig, res: Response) {
        return res.status(404).send('Error: This function is not supported at this time.');
    }
}