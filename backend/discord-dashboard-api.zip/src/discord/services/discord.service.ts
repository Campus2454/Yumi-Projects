import { Inject, Injectable } from "@nestjs/common";
import { IDiscordService } from "../interfaces/discord";
import { SERVICES } from "src/utils/constants";
import { IDiscordHttpService } from "../interfaces/discord-http";
import { InjectRepository } from "@nestjs/typeorm";
import { GuildConfiguration } from "src/utils/typeorm/entities/GuildConfiguration";
import { Raw, Repository } from "typeorm";
import { Membership } from "src/utils/typeorm/entities/Membership";

@Injectable()
export class DiscordService implements IDiscordService {
    constructor(
        @Inject(SERVICES.DISCORD_HTTP) private readonly discordHttpService: IDiscordHttpService,
        @InjectRepository(GuildConfiguration) private readonly guildConfigRepository: Repository<GuildConfiguration>,
        @InjectRepository(Membership) private readonly membershipRepository: Repository<Membership>
    ){}

    getBotGuilds(){
        return this.discordHttpService.fetchBotGuilds();
    }
    getUserGuilds(accessToken: string){
        return this.discordHttpService.fetchUserGuilds(accessToken);
    }
    getGuildData(guildId: string){
        return this.discordHttpService.fetchGuildData(guildId);
    }
    async getMutualGuilds(accessToken: string){
        const { data: userGuilds } = await this.getUserGuilds(accessToken);
        const { data: botGuilds } = await this.getBotGuilds();
        // userGuilds.forEach((guild) => {
        //     const permissions = parseInt(guild.permissions) & 0x8;
        //     console.log(permissions);
        // })
        const adminUserGuilds = userGuilds.filter(({ permissions }) => (parseInt(permissions) & 0x8) === 8);
        const mutualGuilds = userGuilds.filter((guild) => botGuilds.some((botGuilds) => botGuilds.id === guild.id));
        const guilds = await Promise.all(adminUserGuilds.map(async g => {
            const botHere = botGuilds.some((botGuild) => botGuild.id === g.id);
            const config = {
                config: botHere ? await this.guildConfigRepository.findOne({ where: { guildId: g.id } }) : undefined,
                membership: await this.membershipRepository.findOne({ where: { serverId: g.id } }) || await this.membershipRepository.findOne({ where: { serverIds: Raw((alias) => `JSON_CONTAINS(${alias}, :id)`, { id: `"${g.id}"` }) } }) || undefined,
            };
            return {
                ...g,
                bot_here: botHere,
                data: botHere ? (await this.getGuildData(g.id)).data : undefined,
                database: config || undefined
            }
        }));
        return guilds;
    }

    async getUserData(accessToken: string){
        const { data: user } = await this.discordHttpService.fetchUserData(accessToken);
        return user;
    }
}