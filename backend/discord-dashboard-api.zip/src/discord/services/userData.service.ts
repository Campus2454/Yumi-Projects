import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { Client, GatewayIntentBits, User as DiscordUser } from 'discord.js';

// @Injectable()
// export class UserStatusService {
//   private client: Client;

//   constructor() {
//     this.client = new Client({
//       intents: [
//         GatewayIntentBits.Guilds,
//         GatewayIntentBits.GuildPresences,
//         GatewayIntentBits.GuildMembers,
//       ],
//     });

//     this.client.login(process.env.DISCORD_BOT_TOKEN);

//     this.client.once('ready', () => {
//       console.log('Discord bot is online!');
//     });
//   }

//   async getUserPresence(userId: string): Promise<any> {
//     const guild = this.client.guilds.cache.get('1018508978445099098');
//     if (!guild) throw new Error('Guild not found');

//     const member = guild.members.cache.get(userId);
//     const status = member ? member.presence?.status || 'offline' : 'offline';
//     const activities = member.presence?.activities.map(activity => ({
//       name: activity.name,
//       type: activity.type,
//       details: activity.details,
//       state: activity.state,
//       timestamps: activity.timestamps,
//     }));

//     // const response = await axios.get(`https://discord.com/api/users/${userId}`, {
//     //   headers: {
//     //     'Authorization': `Bot ${process.env.DISCORD_BOT_TOKEN}`,
//     //   },
//     // });
//     // if (response.status !== 200) throw new Error('Failed to fetch user data');

//     return {
//       status,
//       activities,
//       // ...response.data
//     };
//   }
// }

@Injectable()
export class UserDataService {
  private client: Client;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMembers,
      ],
    });

    this.client.login(process.env.DISCORD_BOT_TOKEN);

    this.client.once('ready', () => {
      console.log('UserDataService: Discord bot is online!');
    });
  }

  async getUserPresence(userId: string): Promise<any> {
    const guild = this.client.guilds.cache.get('1018508978445099098');
    if (!guild) throw new Error('Guild not found');

    const member = guild.members.cache.get(userId);
    const status = member ? member.presence?.status || 'offline' : 'offline';
    const activities = member.presence?.activities.map(activity => ({
      name: activity.name,
      type: activity.type,
      details: activity.details,
      state: activity.state,
      timestamps: activity.timestamps,
    }));

    const response = await axios.get(`https://discord.com/api/users/${userId}`, {
      headers: {
        'Authorization': `Bot ${process.env.DISCORD_BOT_TOKEN}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch user data');

    return {
      status,
      activities,
      ...response.data
    };
  }
}