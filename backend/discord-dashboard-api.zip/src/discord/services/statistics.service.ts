import { Injectable } from "@nestjs/common";
import { Client, GatewayIntentBits } from "discord.js";

@Injectable()
export class StatisticsService {
    private client: Client;
    constructor() {
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
            ],
        });
        this.client.login(process.env.DISCORD_BOT_TOKEN);
        this.client.once('ready', () => {
            console.log('StatisticsService: Discord bot is online!');
        });
    }
    getStatistics() {
        const guilds = this.client.guilds;
        const guildCount = guilds.cache.size;
        let memberCount = 0;
        guilds.cache.forEach(g => memberCount += g.memberCount);
        return {
            'guilds': guildCount,
            'members': memberCount
        };
    }
}