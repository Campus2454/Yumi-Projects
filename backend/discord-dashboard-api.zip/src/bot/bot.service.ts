import { Activity, ActivityType, Client, PresenceStatusData } from 'discord.js';
import { Response } from 'express';

export class BotService {
    private client: Client;
    constructor() {
        this.client = new Client({ intents: [], });
    }

    async setBotStatus(res: Response, status?: PresenceStatusData | undefined, activity?: Activity | undefined) {
        try{
            await this.client.login(process.env.DISCORD_BOT_TOKEN);

            this.client.on('ready', (client) => {
                console.log('ready', new Date().toUTCString());
                client.user.setPresence({
                    status: status || 'online',
                });
            });

            await this.client.destroy();

            return res.status(200).json({ message: `Status updated successfully!`, status: this.client.user.presence.toJSON() });
        }catch(error){
            throw new Error(`Error setting bot status and activity, Error: ${error}`);
        }
    }
}