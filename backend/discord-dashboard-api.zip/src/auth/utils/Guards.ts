import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";

@Injectable()
export class DiscordAuthGuardDomain extends AuthGuard('discordDomain') {
    async canActivate(context: ExecutionContext) {
        try {
            const activate = (await super.canActivate(context)) as boolean;
            if (activate) {
                const request = context.switchToHttp().getRequest();
                await super.logIn(request);
                return true;
            } else {
                throw new UnauthorizedException('Authentication failed');
            }
        } catch (err) {
            const response = context.switchToHttp().getResponse();
            const request = context.switchToHttp().getRequest();
            const { error } = request.query;
            if (error) response.redirect(`https://camming.xyz/?login_error=${error}`);
            return false;
        }
    }
}

@Injectable()
export class DiscordAuthGuardLocalhost extends AuthGuard('discordLocalhost') {
    async canActivate(context: ExecutionContext) {
        try {
            const activate = (await super.canActivate(context)) as boolean;
            if (activate) {
                const request = context.switchToHttp().getRequest();
                await super.logIn(request);
                return true;
            } else {
                throw new UnauthorizedException('Authentication failed');
            }
        } catch (err) {
            const response = context.switchToHttp().getResponse();
            const request = context.switchToHttp().getRequest();
            const error = err.message || request.query?.error || 'unknown_error';
            console.log('OAuth Code:', request.query);
            response.redirect(`http://210.246.215.139:3000/?login_error=${error}`);
            return false;
        }
    }
}

@Injectable()
export class AuthenticatedGuard implements CanActivate {
    async canActivate(context: ExecutionContext): Promise<boolean> {
        const req = context.switchToHttp().getRequest();
        return req.isAuthenticated();
    }
}