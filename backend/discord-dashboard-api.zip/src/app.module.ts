import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { entities } from './utils/typeorm';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { PassportModule } from '@nestjs/passport';
import { DiscordModule } from './discord/discord.module';
import { MainController } from './main.controller';
import { PaymentModule } from './payment/payment.module';
import { MailerModule } from './mailer/mailer.module';
import { BotModule } from './bot/bot.module';
import { TurnstileModule } from './turnstile/turnstile.module';
import { TurnstileMiddleware } from './turnstile.middleware';
import { LimitMiddleware } from './limit.middleware';

@Module({
  imports: [
    ConfigModule.forRoot({ envFilePath: '.env.development' }),
    PassportModule.register({ session: true }),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.MYSQL_DB_HOST,
      port: 3306,
      username: process.env.MYSQL_DB_USER,
      password: process.env.MYSQL_DB_PASSWORD,
      database: process.env.MYSQL_DB_DATABASE,
      synchronize: true,
      entities: entities,
    }),
    AuthModule,
    UserModule,
    DiscordModule,
    PaymentModule,
    MailerModule,
    BotModule,
    TurnstileModule,
  ],
  controllers: [
    MainController,
  ],
  providers: [],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LimitMiddleware).forRoutes('*');
    consumer.apply(TurnstileMiddleware).forRoutes('*');
  }
}
