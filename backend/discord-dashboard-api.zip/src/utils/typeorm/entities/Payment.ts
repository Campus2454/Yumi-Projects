import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'payments' })
export class Payment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ name: 'discord_id', })
    discordId: string;

    @Column({ name: 'slip_url', unique: true, })
    slipUrl: string;

    @Column({ name: 'is_verified', default: false, })
    isVerified: boolean;

    @Column({ name: 'membership_type', type: 'enum', enum: ['premium', 'membership'], unique: true, })
    membershipType: string;

    @Column({ name: 'amount', type: 'decimal', precision: 10, scale: 2 })
    amount: number;

    @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
    createdAt: Date;
}