import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'guild_configurations' })
export class GuildConfiguration {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ unique: true , name: 'guild_id' })
    guildId: string;

    @Column({ default: '!' })
    prefix: string;

    @Column({ type: 'text', name: 'audit_log_settings', nullable: true })
    auditLogSettings: string | null;

    @Column({ type: 'json', name: 'welcome', nullable: true })
    welcome: {
        channel: { isEnabled: boolean, id: string | null, message: string | null, default_message_type: 'th' | 'en', message_type: 'default' | 'custom' } | null,
        user: { isEnabled: boolean, message: string | null, default_message_type: 'th' | 'en', message_type: 'default' | 'custom' } | null
    } | null
}
